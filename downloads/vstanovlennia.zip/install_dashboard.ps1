﻿param(
    # Куда ставим. Менять не нужно — путь совпадает с тем, что зашит
    # в update_client.ps1, иначе обновлялка не найдёт установку.
    [string]$InstallDir = 'C:\parts-dashboard'
)

# install_dashboard.ps1 — установка Parts Dashboard «в один клик» у НОВОГО клиента.
# Запускается через «Встановити.bat» (двойной клик), лежит с ним в одной папке.
#
# Что делает: ставит Python (если его нет), качает дашборд, настраивает
# автозапуск, поднимает сервер и открывает браузер. Клиенту делать ничего
# не надо — ни PATH, ни pip, ни отдельного батника автозагрузки.
#
# Обновлением НЕ занимается: для этого у клиента есть кнопка в дашборде и
# update.bat. Если дашборд уже стоит — скрипт отказывается работать, чтобы
# не затереть config.json с логинами и лицензией.
#
# Все ID файлов берём из version.json (его ID вечен — он зашит в app.py и
# update_client.ps1 у всех клиентов). Питон и архив на Drive после этого
# можно перезаливать свободно, достаточно поправить version.json.

$ErrorActionPreference = 'Stop'
try { [Console]::OutputEncoding = [Text.Encoding]::UTF8 } catch {}
$ProgressPreference = 'SilentlyContinue'
try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch {}

# ====================== НАСТРОЙКИ ======================
$VersionFileId = '1-A6VTHDjMm9noCrlKmftlSvOBJocACel'   # version.json — ВЕЧНЫЙ ID, не менять
$ZipIdFallback = '12vn196DZ7FxCHzYZmbNw825x2OWiOR9y'   # архив дашборда, если version.json не достучался
$PyIdFallback  = '10VQvJO6MtoOkCCAfuFdewJzb4md-OojD'   # python-3.14.6-amd64.exe, туда же
$MinPyMajor = 3
$MinPyMinor = 11                                        # ниже 3.11 наши колёса abi3 не встанут
$DashboardUrl = 'http://127.0.0.1:5000'
# =======================================================

$TempDir = Join-Path $env:TEMP 'pd-install'
$ok = [char]0x2713   # ✓

function DriveUrl($id) { "https://drive.usercontent.google.com/download?id=$id&export=download&confirm=t" }

function Say($text, $color = 'White') { Write-Host $text -ForegroundColor $color }

function Step($n, $text) {
    Write-Host ''
    Write-Host "[$n/7] $text" -ForegroundColor Cyan
}

function Done($text) { Write-Host "      $ok $text" -ForegroundColor Green }

# Move-Item ломается, если рабочий диск процесса совпадает с диском пути,
# где-то внутри которого есть короткое 8.3-имя (напр. C:\Users\B9DE4~1.LIS
# у клиента с точкой в логіні — Windows сама генерит такой алиас): падает
# с «object at the specified path ... does not exist», хотя папка есть
# (баг воспроизведён 2026-07-28). Copy-Item ловит ТОТ ЖЕ баг резолвинга —
# это не квирк конкретно Move-Item, а общий баг FileSystem-провайдера
# PowerShell. Голый [IO.Directory]::Move его не имеет, но и не умеет
# переносить между разными дисками ("must have identical roots") — на
# случай, если %TEMP% у кого-то окажется не на диске установки, ниже
# ручной рекурсивный перенос чистым .NET (Directory/File API), без единого
# командлета файловой системы.
function Move-DirSafe($From, $To) {
    if ([IO.Path]::GetPathRoot($From) -ieq [IO.Path]::GetPathRoot($To)) {
        [IO.Directory]::Move($From, $To)
        return
    }
    function _CopyDirRec($f, $t) {
        [IO.Directory]::CreateDirectory($t) | Out-Null
        foreach ($file in [IO.Directory]::GetFiles($f)) {
            [IO.File]::Copy($file, [IO.Path]::Combine($t, [IO.Path]::GetFileName($file)), $true)
        }
        foreach ($dir in [IO.Directory]::GetDirectories($f)) {
            _CopyDirRec $dir ([IO.Path]::Combine($t, [IO.Path]::GetFileName($dir)))
        }
    }
    _CopyDirRec $From $To
    [IO.Directory]::Delete($From, $true)
}

function Fail($msg) {
    Write-Host ''
    Write-Host '─────────────────────────────────────────────' -ForegroundColor Red
    Write-Host "НЕ ВДАЛОСЯ ВСТАНОВИТИ" -ForegroundColor Red
    Write-Host ''
    Write-Host $msg -ForegroundColor Yellow
    Write-Host ''
    Write-Host 'Нічого страшного не сталося — комп''ютер не змінено.' -ForegroundColor White
    Write-Host 'Покажіть це вікно тому, хто вам надав програму.' -ForegroundColor White
    Write-Host '─────────────────────────────────────────────' -ForegroundColor Red
    Read-Host 'Натисніть Enter для виходу'
    exit 1
}

Clear-Host
Write-Host '═════════════════════════════════════════════' -ForegroundColor Cyan
Write-Host '   Встановлення Автопошуку Запчастин' -ForegroundColor Cyan
Write-Host '═════════════════════════════════════════════' -ForegroundColor Cyan
Write-Host ''
Write-Host 'Займе 2-5 хвилин. Нічого натискати не треба —' -ForegroundColor White
Write-Host 'наприкінці програма відкриється сама.' -ForegroundColor White
Write-Host 'Не закривайте це вікно.' -ForegroundColor Yellow

# ─────────── 0. Перевірки середовища ───────────
Step 1 'Перевіряю комп''ютер...'

if (-not [Environment]::Is64BitOperatingSystem) {
    Fail "У вас 32-бітна Windows, а програма потребує 64-бітну.`nНа жаль, встановити не вийде."
}
if ([Environment]::OSVersion.Version.Major -lt 10) {
    Fail "У вас Windows $([Environment]::OSVersion.Version.Major), а потрібна Windows 10 або новіша."
}
Done 'Windows підходить'

# Дашборд уже стоит? Тогда это не установка, а попытка переустановки —
# молча продолжить нельзя: затрём config.json с логинами и лицензией.
if (Test-Path (Join-Path $InstallDir 'app.py')) {
    Write-Host ''
    Say 'Дашборд вже встановлено на цьому комп''ютері.' 'Yellow'
    Say "Папка: $InstallDir" 'White'
    Write-Host ''
    Say 'Щоб ОНОВИТИ програму — не використовуйте цей файл:' 'White'
    Say '  відкрийте дашборд і натисніть «Оновити» в налаштуваннях' 'Cyan'
    Say "  або запустіть $InstallDir\update.bat" 'Cyan'
    Write-Host ''
    Say 'Встановлення заново стерло б ваші логіни, паролі та ліцензію,' 'Yellow'
    Say 'тому я нічого не чіпаю.' 'Yellow'
    Write-Host ''
    Read-Host 'Натисніть Enter для виходу'
    exit 0
}

if (Test-Path $TempDir) { Remove-Item $TempDir -Recurse -Force -ErrorAction SilentlyContinue }
New-Item -ItemType Directory -Path $TempDir -Force | Out-Null

# ─────────── 1. version.json: свежие ID файлов ───────────
Step 2 'Зв''язуюся з сервером оновлень...'

$zipId = $ZipIdFallback
$pyId  = $PyIdFallback
try {
    $raw = (Invoke-WebRequest -Uri (DriveUrl $VersionFileId) -UseBasicParsing -TimeoutSec 30).Content
    if ($raw -is [byte[]]) { $raw = [Text.Encoding]::UTF8.GetString($raw) }
    $meta = $raw | ConvertFrom-Json
    if ($meta.zip_id)    { $zipId = $meta.zip_id }
    if ($meta.python_id) { $pyId  = $meta.python_id }
    if ($meta.version)   { Done "Версія програми: $($meta.version)" } else { Done 'Готово' }
} catch {
    # Не смертельно: ID у нас зашиты запасные. Смертельно будет ниже,
    # если и по ним не скачается — тогда дело в интернете.
    Say '      Сервер оновлень не відповів, беру резервні посилання.' 'Yellow'
}

# ─────────── 2. Python ───────────
Step 3 'Шукаю Python...'

function Test-PythonExe {
    <#
      Проверяет конкретный питон: живой ли и достаточно ли свежий.
      Возвращает путь к python.exe или $null.
      Заглушку из Microsoft Store отсеиваем по пути: это файл в 0 байт,
      который при запуске открывает магазин вместо питона.
    #>
    param([string]$Exe, [string[]]$PreArgs = @())

    if (-not $Exe) { return $null }
    if ($Exe -like '*\WindowsApps\*') { return $null }

    # В пробнике НЕЛЬЗЯ использовать двойные кавычки: PowerShell 5.1 съедает
    # их при передаче аргумента внешней программе, питон получает битый код
    # и молча падает — а мы решаем, что питона нет, и ставим второй поверх.
    # Поэтому печатаем через запятую (разделитель — пробел) и разбираем
    # регексом: путь может содержать пробелы, его забирает жадный хвост.
    $probe = 'import sys; print(sys.version_info[0], sys.version_info[1], sys.executable)'
    # Снимаем Stop так же, как для pip: питон может брякнуть что-нибудь в
    # stderr (устаревший модуль, кривой sitecustomize), а PowerShell 5.1
    # сделает из этого фатальную ошибку. Молча решить «питона нет» нельзя —
    # поставим второй поверх рабочего.
    $prevEAP = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    try {
        $out = & $Exe @PreArgs '-c' $probe 2>$null
    } catch {
        $out = $null
    } finally {
        $ErrorActionPreference = $prevEAP
    }
    if (-not $out) { return $null }

    $line = ($out | Select-Object -Last 1).ToString().Trim()
    if ($line -notmatch '^(\d+)\s+(\d+)\s+(.+)$') { return $null }

    $maj = [int]$Matches[1]; $min = [int]$Matches[2]; $real = $Matches[3]
    if ($maj -lt $MinPyMajor) { return $null }
    if ($maj -eq $MinPyMajor -and $min -lt $MinPyMinor) { return $null }
    if ($real -like '*\WindowsApps\*') { return $null }
    return $real
}

function Find-Python {
    # Порядок важен: сначала лаунчер (он сам выберет самую свежую версию),
    # потом python из PATH, потом типовые места установки.
    $found = Test-PythonExe -Exe 'py' -PreArgs @('-3')
    if ($found) { return $found }

    $cmd = Get-Command python -ErrorAction SilentlyContinue
    if ($cmd) {
        $found = Test-PythonExe -Exe $cmd.Source
        if ($found) { return $found }
    }

    $roots = @(
        (Join-Path $env:LOCALAPPDATA 'Programs\Python'),
        $env:ProgramFiles,
        'C:\'
    )
    foreach ($root in $roots) {
        if (-not (Test-Path $root)) { continue }
        $dirs = Get-ChildItem $root -Directory -Filter 'Python3*' -ErrorAction SilentlyContinue |
                Sort-Object Name -Descending
        foreach ($d in $dirs) {
            $found = Test-PythonExe -Exe (Join-Path $d.FullName 'python.exe')
            if ($found) { return $found }
        }
    }
    return $null
}

$python = Find-Python

if ($python) {
    Done "Python вже є: $python"
} else {
    Say "      Python не знайдено — встановлюю (це найдовший крок)." 'White'

    $pyExe = Join-Path $TempDir 'python-setup.exe'
    try {
        Invoke-WebRequest -Uri (DriveUrl $pyId) -OutFile $pyExe -UseBasicParsing -TimeoutSec 600
    } catch {
        Fail "Не вдалося завантажити Python: $($_.Exception.Message)`nПеревірте інтернет і спробуйте ще раз."
    }
    # Битый/подменённый файл ловим до запуска: MZ — сигнатура exe.
    $head = [IO.File]::ReadAllBytes($pyExe)[0..1]
    if ((Get-Item $pyExe).Length -lt 5MB -or [char]$head[0] + [char]$head[1] -ne 'MZ') {
        Fail 'Завантажений файл Python пошкоджено. Спробуйте ще раз.'
    }

    # InstallAllUsers=0 — ставим в профиль пользователя, поэтому прав
    # администратора не нужно и окно UAC не выскочит.
    # Имя $args НЕ использовать — это встроенная переменная PowerShell.
    $pyArgs = @('/quiet', 'InstallAllUsers=0', 'PrependPath=1', 'Include_test=0', 'Include_launcher=1')
    $proc = Start-Process -FilePath $pyExe -ArgumentList $pyArgs -Wait -PassThru
    if ($proc.ExitCode -ne 0 -and $proc.ExitCode -ne 3010) {
        Fail "Встановлення Python завершилося з помилкою (код $($proc.ExitCode))."
    }

    # PATH текущего процесса не обновляется автоматически, а его унаследует
    # сервер, который мы запустим в конце — подтягиваем из реестра вручную.
    $env:Path = [Environment]::GetEnvironmentVariable('Path', 'Machine') + ';' +
                [Environment]::GetEnvironmentVariable('Path', 'User')

    $python = Find-Python
    if (-not $python) {
        Fail "Python встановлено, але знайти його не вдалося.`nСпробуйте перезавантажити комп'ютер і запустити встановлення ще раз."
    }
    Done "Python встановлено: $python"
}

# ─────────── 3. Архив дашборда ───────────
Step 4 'Завантажую програму...'

$zipPath = Join-Path $TempDir 'parts-dashboard.zip'
try {
    Invoke-WebRequest -Uri (DriveUrl $zipId) -OutFile $zipPath -UseBasicParsing -TimeoutSec 600
} catch {
    Fail "Не вдалося завантажити програму: $($_.Exception.Message)`nПеревірте інтернет і спробуйте ще раз."
}
if (-not (Test-Path $zipPath) -or (Get-Item $zipPath).Length -lt 100KB) {
    Fail 'Архів програми не завантажився або пошкоджений. Спробуйте ще раз.'
}
Done 'Завантажено'

# ─────────── 4. Распаковка ───────────
Step 5 'Розпаковую...'

$extract = Join-Path $TempDir 'extracted'
try {
    Expand-Archive -Path $zipPath -DestinationPath $extract -Force
} catch {
    Fail "Не вдалося розпакувати архів: $($_.Exception.Message)"
}

# Корень проекта — там, где лежит app.py (архив бывает «папка в папке»).
$src = $extract
if (-not (Test-Path (Join-Path $src 'app.py'))) {
    $appFile = Get-ChildItem $extract -Recurse -Filter 'app.py' -File -ErrorAction SilentlyContinue |
               Select-Object -First 1
    if ($appFile) { $src = $appFile.Directory.FullName }
}
if (-not (Test-Path (Join-Path $src 'app.py'))) {
    Fail 'В архіві не знайдено програму (app.py) — архів пошкоджений.'
}

try {
    $parent = Split-Path $InstallDir -Parent
    if (-not (Test-Path $parent)) { New-Item -ItemType Directory -Path $parent -Force | Out-Null }
    # Пустая папка C:\parts-dashboard могла остаться от прошлых попыток:
    # app.py в ней нет (проверено в шаге 1), значит удалить безопасно.
    if (Test-Path $InstallDir) { Remove-Item $InstallDir -Recurse -Force }
    Move-DirSafe $src $InstallDir
} catch {
    Fail "Не вдалося створити папку $InstallDir : $($_.Exception.Message)"
}
Done "Встановлено в $InstallDir"

# ─────────── 5. Зависимости ───────────
Step 6 'Встановлюю компоненти (хвилина-дві)...'

$req = Join-Path $InstallDir 'requirements.txt'
if (Test-Path $req) {
    # ОСТОРОЖНО: pip регулярно пишет в stderr БЕЗОБИДНЫЕ предупреждения
    # (например «pip.exe is not on PATH»), а PowerShell 5.1 при
    # ErrorActionPreference='Stop' превращает любой stderr нативной
    # программы в фатальный NativeCommandError. На боевой установке это
    # убивало скрипт на ровном месте. Поэтому на время вызова снимаем Stop
    # и судим об успехе ТОЛЬКО по коду возврата, а вывод копим — он
    # понадобится, если pip действительно упадёт.
    $prevEAP = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    $pipLog = & $python -m pip install -r $req --disable-pip-version-check 2>&1
    $pipCode = $LASTEXITCODE
    $ErrorActionPreference = $prevEAP

    if ($pipCode -ne 0) {
        $tail = ($pipLog | Select-Object -Last 15) -join "`n"
        Fail ("Не вдалося встановити компоненти програми.`n" +
              "Найчастіше це обрив інтернету — просто запустіть встановлення ще раз.`n`n" +
              "Технічні подробиці:`n$tail")
    }
    Done 'Компоненти встановлено'
} else {
    Say '      requirements.txt не знайдено, пропускаю.' 'Yellow'
}

# ─────────── 6. Автозапуск + ярлык ───────────
Step 7 'Налаштовую автозапуск...'

$vbs = Join-Path $InstallDir 'start_dashboard.vbs'
if (-not (Test-Path $vbs)) {
    Fail "В архіві не знайдено start_dashboard.vbs — архів пошкоджений."
}

$shell = New-Object -ComObject WScript.Shell

# Ярлык в автозагрузке — дашборд сам поднимется после включения компьютера.
$startup = [Environment]::GetFolderPath('Startup')
$lnk = $shell.CreateShortcut((Join-Path $startup 'Parts Dashboard.lnk'))
$lnk.TargetPath       = 'wscript.exe'
$lnk.Arguments        = "`"$vbs`""
$lnk.WorkingDirectory = $InstallDir
$lnk.Description      = 'Автозапуск Автопошуку Запчастин у фоні'
$lnk.Save()
Done 'Автозапуск налаштовано'

# Ярлык на рабочем столе — просто ссылка на страницу. Сервер уже работает
# в фоне, поэтому запускать его повторно не нужно (и вредно: другой процесс
# не займёт порт и упадёт).
$desktop = [Environment]::GetFolderPath('Desktop')
$url = Join-Path $desktop 'Автопошук Запчастин.url'

# Своя иконка (синий круг с машинкой — тот же эмодзи, что на вкладке).
# В сборках до 2026-07-19 файла нет: тогда IconFile не пишем вовсе, иначе
# Windows покажет пустой квадрат вместо иконки браузера по умолчанию.
$icoPath = Join-Path $InstallDir 'dashboard.ico'
$iconLines = ''
if (Test-Path $icoPath) { $iconLines = "IconFile=$icoPath`r`nIconIndex=0`r`n" }

"[InternetShortcut]`r`nURL=$DashboardUrl`r`n$iconLines" |
    Set-Content -Path $url -Encoding ASCII -NoNewline
Done 'Ярлик на робочому столі створено'

# ─────────── 7. Запуск и проверка ───────────
Write-Host ''
Say 'Запускаю...' 'Cyan'

Start-Process 'wscript.exe' -ArgumentList "`"$vbs`"" -WorkingDirectory $InstallDir

# Не открываем браузер вслепую: сначала убеждаемся, что сервер реально
# ответил. Иначе клиент увидит «не удаётся подключиться» и решит, что
# установка провалилась.
$alive = $false
foreach ($i in 1..40) {
    Start-Sleep -Seconds 2
    try {
        $r = Invoke-WebRequest -Uri $DashboardUrl -UseBasicParsing -TimeoutSec 3
        if ($r.StatusCode -eq 200) { $alive = $true; break }
    } catch {}
    if ($i % 5 -eq 0) { Write-Host '   ...' -NoNewline }
}
Write-Host ''

Remove-Item $TempDir -Recurse -Force -ErrorAction SilentlyContinue

if (-not $alive) {
    Write-Host ''
    Say '─────────────────────────────────────────────' 'Yellow'
    Say 'Програму встановлено, але вона не відповіла за 80 секунд.' 'Yellow'
    Write-Host ''
    Say 'Спробуйте перезавантажити комп''ютер — після цього' 'White'
    Say 'дашборд запуститься сам. Якщо не допоможе — покажіть' 'White'
    Say 'це вікно тому, хто вам надав програму.' 'White'
    Say "Папка програми: $InstallDir" 'White'
    Say '─────────────────────────────────────────────' 'Yellow'
    Read-Host 'Натисніть Enter для виходу'
    exit 1
}

Start-Process $DashboardUrl

Write-Host ''
Write-Host '═════════════════════════════════════════════' -ForegroundColor Green
Write-Host "   $ok  ГОТОВО! Програму встановлено." -ForegroundColor Green
Write-Host '═════════════════════════════════════════════' -ForegroundColor Green
Write-Host ''
Say 'Дашборд відкрився у браузері.' 'White'
Say 'Він запускатиметься сам після кожного вмикання комп''ютера.' 'White'
Say 'На робочому столі є ярлик «Автопошук Запчастин».' 'White'
Write-Host ''
Say 'ЩО ДАЛІ: відкрийте налаштування (⚙) і введіть' 'Cyan'
Say 'ліцензійний ключ та логіни до постачальників.' 'Cyan'
Write-Host ''
Write-Host 'Це вікно закриється через 20 секунд...'
Start-Sleep -Seconds 20
exit 0
