@echo off
chcp 65001 >nul

rem === KEEP THIS FILE 100%% ASCII - NO CYRILLIC ANYWHERE ===
rem cmd.exe parses .bat by byte offsets. Any multi-byte UTF-8 character
rem shifts those offsets, and "goto"/parenthesized blocks then jump to
rem the wrong place - cmd starts executing fragments of other lines as
rem commands. Verified 2026-07-19: even ASCII-only comments did not help
rem while Ukrainian text sat further down the file.
rem That is why this file is linear (no goto, no blocks) and speaks
rem English only. All user-facing Ukrainian text lives in
rem install_dashboard.ps1, which is UTF-8 with BOM and has no such issue.

title Avtoposhuk Zapchastyn - vstanovlennya

if not exist "%~dp0install_dashboard.ps1" echo. & echo   ROZPAKUYTE ARHIV U PAPKU: prava knopka -^> "Vydobuty vse..." & echo   (rosiyskoyu Windows: "Izvlech vse..."), & echo   a potim zapustit VSTANOVYTY vzhe z tiyeyi papky. & echo. & pause & exit /b 1

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install_dashboard.ps1"

if errorlevel 1 pause
